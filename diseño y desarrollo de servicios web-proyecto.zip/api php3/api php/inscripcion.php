<?php

session_start();
if (isset($_SESSION['id'])) {
  require_once "controller/errores.php";
  require_once "controller/inscripcionC.php";
  $_respuestas = new respuestas;
  $_inscripcion = new inscripcion;

  if ($_SERVER['REQUEST_METHOD'] == "GET") {
    if (isset($_GET["pagina"])) {
      $pagina = $_GET["pagina"];
      $datos = $_inscripcion->listarInscripcion($pagina);
      header('Content-Type: application/json');
      echo json_encode($datos);
    } else if (isset($_GET["id"])) {
      $id = $_GET["id"];
      $datos = $_inscripcion->listarId($id);
      header('Content-Type: application/json');
      echo json_encode($datos);
    } else {
      $datos = $_inscripcion->listarInscripcion();
      header('Content-Type: application/json');
      echo json_encode($datos);
    }
  } else if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $postBody = file_get_contents("php://input");
    //Enviar datos al metodo login (json)
    $datosArray = $_inscripcion->Inscripcion($postBody);
    //Devolver datos en pagina
    header('Content-Type: application/json');
    echo json_encode($datosArray);
  } else {
    header('Content-Type: application/json');
    $datosArray = $_respuestas->error_405();
    echo json_encode($datosArray);
  }
} else if (isset($_GET["cerrar"]) == "cerrar") {
  session_destroy();
  echo "Se ha cerrado la sesion";
} else {
  echo "No hay una sesion activa";
}
