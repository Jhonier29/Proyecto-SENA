<?php
//  llamar la clase de autenticacion
require_once "controller/authc.php";
//  llamar la clase de respuestas a errores o excepciones
require_once "controller/errores.php";
// instaciar la clase de autenticacion
$_auth = new auth;
// instaciar la clase de respuestas
$_respuestas = new respuestas;
// instaciar la clase de errores 
$_errores = new respuestas;
//  requerir el metodo POST


if ($_SERVER['REQUEST_METHOD'] == "POST") {
  //Recibir datos del body de la peticion POST y enviarlos al metodo login
  $postBody = file_get_contents("php://input");
  //Enviar datos al metodo login (json)
  $datosArray = $_auth->login($postBody);

  //Devolver datos en pagina
  header('Content-Type: application/json');

  if (isset($datosArray["result"]["error_id"])) {
    $reponseCode = $datosArray["result"]["error_id"];
    //  devolver variable result con valor de error clase de respuestas
    http_response_code($reponseCode);
  } else {
    //  devolver variable result con valor de la respuesta correcta
    http_response_code(200);
    //  agregar datos al array resultado para mostar en pagina

  }
  echo (json_encode($datosArray));
} else {
  header('Content-Type: application/json');
  //  devolver error si el metodo no es POST
  if ($_SERVER['REQUEST_METHOD'] != "POST" || $_SERVER['REQUEST_METHOD'] != "GET") {
    $datosArray = $_respuestas->error_200("Para usar ver el archivo README del proyecto, para acceder a los metodos");
  } else {
    $reponseCode = 405;
    $datosArray = $_respuestas->error_405();
  }
  echo json_encode($datosArray);
}
