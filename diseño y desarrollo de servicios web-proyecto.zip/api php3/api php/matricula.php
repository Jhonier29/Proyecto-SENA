<?php

session_start();
if (isset($_SESSION['id'])) {
  require_once "controller/errores.php";
  require_once "controller/matriculaC.php";
  $_respuestas = new respuestas;
  $_matricula = new matricula;

  if ($_SERVER['REQUEST_METHOD'] == "GET") {
    if (isset($_GET["pagina"])) {
      $pagina = $_GET["pagina"];
      $datos = $_matricula->listarMatricula($pagina);
      header('Content-Type: application/json');
      echo json_encode($datos);
    } else if (isset($_GET["id"])) {
      $id = $_GET["id"];
      $datos = $_matricula->listarId($id);
      header('Content-Type: application/json');
      echo json_encode($datos);
    } else {
      $datos = $_matricula->listarMatricula();
      header('Content-Type: application/json');
      echo json_encode($datos);
    }
  } else if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $postBody = file_get_contents("php://input");
    //Enviar datos al metodo login (json)
    $datosArray = $_matricula->matricula($postBody);
    //Devolver datos en pagina
    header('Content-Type: application/json');
    echo json_encode($datosArray);
  } else {
    header('Content-Type: application/json');
    $datosArray = $_respuestas->error_405();
    echo json_encode($datosArray);
  }
} else if (isset($_GET["cerrar"]) == "cerrar") {
  session_destroy();
  echo "Se ha cerrado la sesion";
} else {
  echo "No hay una sesion activa";
}
