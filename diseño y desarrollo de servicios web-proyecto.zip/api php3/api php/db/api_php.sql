
CREATE DATABASE IF NOT EXISTS `api_cecdet` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `api_cecdet`;


CREATE TABLE `inscripcion` (
  `id_inscripcion` int(11) NOT NULL,
  `programa` varchar(255) NOT NULL,
  `fecha` date NOT NULL,
  `id_usuario` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



INSERT INTO `inscripcion` (`id_inscripcion`, `programa`, `fecha`, `id_usuario`) VALUES
(1, 'administracion de empresas', '2024-05-01', 17),
(2, 'Contabilidad', '2024-05-02', 18),
(3, 'administracion de empresas', '2024-05-01', 20),
(4, 'Contabilidad', '2024-05-02', 19),
(30, 'programacion', '2024-04-14', 17),
(31, 'programacion', '2024-04-14', 17);



CREATE TABLE `matricula` (
  `id_matricula` int(11) NOT NULL,
  `fecha_inicio` date NOT NULL,
  `programa` varchar(255) NOT NULL,
  `estado` varchar(255) NOT NULL,
  `id_inscripcion` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



INSERT INTO `matricula` (`id_matricula`, `fecha_inicio`, `programa`, `estado`, `id_inscripcion`) VALUES
(1, '2024-05-11', 'mgmhgjyh', 'matriculado', 31),
(2, '2024-05-11', 'mgmhgjyh', 'matriculado', 31),
(3, '2024-05-11', 'mgmhgjyh', 'matriculado', 31),
(4, '2024-05-11', 'mgmhgjyh', 'matriculado', 31);



CREATE TABLE `usuario` (
  `id` int(11) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `apellido` varchar(255) NOT NULL,
  `correo` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `estado` varchar(50) NOT NULL,
  `identificacion` int(255) DEFAULT NULL,
  `fecha_nacimiento` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


INSERT INTO `usuario` (`id`, `nombre`, `apellido`, `correo`, `password`, `estado`, `identificacion`, `fecha_nacimiento`) VALUES
(17, 'Camilo', 'Bautista', 'camilovarga2002@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', 'Activo', 2147483647, '2024-04-14');


ALTER TABLE `inscripcion`
  ADD PRIMARY KEY (`id_inscripcion`),
  ADD KEY `id_usuario` (`id_usuario`);


ALTER TABLE `matricula`
  ADD PRIMARY KEY (`id_matricula`);


ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `inscripcion`
  MODIFY `id_inscripcion` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;


ALTER TABLE `matricula`
  MODIFY `id_matricula` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;


ALTER TABLE `usuario`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;





