<?php
// clase de conexion a la base de datos

// se requiere la la informacion del archivo config que tiene los datos de la base de datos 
class Conexion
{
  // metodos privados de la clase
  private $host;
  private $db;
  private $user;
  private $pass;

  // Funcion contructora de la conexion
  function __construct()
  {
    $listdatos = $this->datosConexion();
    foreach ($listdatos as $key => $value) {
      $this->host = $value['host'];
      $this->db = $value['db'];
      $this->user = $value['user'];
      $this->pass = $value['pass'];
    }
    $this->conexion = new mysqli($this->host, $this->user, $this->pass, $this->db);
    if ($this->conexion->connect_errno) {
      // validacion de la conexion de la base de datos
      echo "Error en la conexion";
      exit();
    }
  }
  // obtener datos del archivo config para la conexion
  private function datosConexion()
  {
    $direccion = dirname(__FILE__);
    $jsondata = file_get_contents($direccion . "/" . "config");
    return json_decode($jsondata, true);
  }
  // funcion para mostar datos
  public function obtenerDatos($query)
  {
    $resultado = $this->conexion->query($query);
    $resultArray = array();
    while ($fila = $resultado->fetch_assoc()) {
      $resultArray[] = $fila;
    }
    return $resultArray;
  }
  // funcion para registrar nuevo usuario
  public function registrar($query)
  {
    $resultado = $this->conexion->query($query);
    return $this->conexion->affected_rows;
  }

  // Encriptacionde clave al registrar
  protected function encriptar($valor)
  {
    return md5($valor);
  }
}
