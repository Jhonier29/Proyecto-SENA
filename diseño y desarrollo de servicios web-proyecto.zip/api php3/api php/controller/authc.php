<?php
//  requerir el archivo de la clase de conexion a la base de datos
require_once "conexion.php";
//  requerir el archivo de las respuestas a errores o excepciones
require_once "errores.php";
// Clase de autenticacion extende de la clase de la base de datos para usar los metodos o (funciones)  definidos de la clase conexion
class auth extends Conexion
{
  //  metodo para iniciar sesion
  public function login($json)
  {
    // almacenar respuestas en una variable
    $_respuestas = new respuestas;
    // decodificar el json en la variable datos
    $datos = json_decode($json, true);
    // validacion de datos
    if (!isset($datos['correo']) || !isset($datos['password'])) {
      // devolver respuesta de error campos de entradas mal escritos o vacios
      return $_respuestas->error_400();
    } else {
      // devolver datos si son validos o correctos
      // almacenar el correo y el password en variables 

      $correo = $datos['correo'];
      $password = $datos['password'];
      $nombre = isset($datos['nombre']) ? $datos['nombre'] : "";
      $apellido = isset($datos['apellido']) ? $datos['apellido'] : "";
      $identificacion = isset($datos['identificacion']) ? $datos['identificacion'] : "";
      $fecha_nacimiento = isset($datos['fecha_nacimiento']) ? $datos['fecha_nacimiento'] : "";

      if ($nombre && $apellido && $identificacion && $fecha_nacimiento) {
        // obtener datos del usuario si exise correo en la base de datos y obtenerlos
        $valreg = $this->obtenerDatosUsuario($correo);
        if (!$valreg) {
          $passwordb = parent::encriptar($password);
          $datos = $this->registrarUsuario($nombre, $apellido, $correo, $passwordb, $identificacion, $fecha_nacimiento);
          return $_respuestas->registrado();
        } else {
          //  devolver error si el usuario no existe
          return $_respuestas->error_200("El usuario con el '$correo' ya se encuentra registrado");
        }
      } else {
        // encriptar password
        $password = parent::encriptar($password);
        // obtener datos del usuario si exise correo en la base de datos y obtenerlos
        $datos = $this->obtenerDatosUsuario($correo);

        // validacion de datos en la base de datos
        if ($datos) {
          // validacion de password de body y de la base de datos
          if ($password == $datos[0]['password']) {
            // validacion de estado del usuario
            if ($datos[0]['estado'] == "Activo") {
              // devolver datos del usuario
              //  devolver varibale result con valor de la respuesta correcta
              $result = $_respuestas->response;
              //  agregar datos al array resultado para mostar en pagina
              $result['result'] = array(
                "Usuario logueado" => $datos[0]['nombre'] . " " . $datos[0]['apellido'],
                "Correo" => $datos[0]['correo'],
                "Estado" => $datos[0]['estado'],
                "Password" => $datos[0]['password']
              );
              session_start();
              $_SESSION['id'] = $datos[0]['id'];
              $_SESSION['nombre'] = $datos[0]['nombre'];
              $_SESSION['apellido'] = $datos[0]['apellido'];
              $_SESSION['identificacion'] = $datos[0]['identificacion'];
              $_SESSION['fecha_nacimiento'] = $datos[0]['fecha_nacimiento'];

              //  devolver variable result con valor de la respuesta correcta
              return $result;
            } else {
              //  devolver error si el usuario se encuentra inactivo
              return $_respuestas->error_200("El usuario se encuentra Inactivo");
            }
          } else {
            //  devolver error si el password es invalido
            return $_respuestas->error_200("El password es invalido");
          }
        } else {
          //  devolver error si el usuario no existe
          return $_respuestas->error_200("El usuario con el $correo no se encuentra registrado");
        }
      }
    }
  }
  // metodo para obtener datos de usuario de la base de datos
  private function obtenerDatosUsuario($correo)
  {
    $query = "SELECT id, nombre, apellido, password, estado, correo, identificacion, fecha_nacimiento from usuario WHERE correo = '$correo'";
    // obtener datos de la base de datos y devolverlos por la funcion
    $datos = parent::obtenerDatos($query);
    if (isset($datos[0]['id'])) {
      return $datos;
    } else {
      return 0;
    }
  }
  private function registrarUsuario($nombre, $apellido, $correo, $password, $identificacion, $fecha_nacimiento)
  {
    $query = "INSERT INTO usuario(id, nombre, apellido, correo, password, estado, identificacion, fecha_nacimiento) VALUES (null,'$nombre','$apellido','$correo','$password','Activo', '$identificacion', '$fecha_nacimiento')";
    // obtener datos de la base de datos y devolverlos por la funcion
    $datos = parent::registrar($query);
    if (isset($datos)) {
      return $datos;
    } else {
      return 0;
    }
  }
}
