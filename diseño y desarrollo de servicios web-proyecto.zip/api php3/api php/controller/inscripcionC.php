<?php

require_once "conexion.php";
require_once "errores.php";

class inscripcion extends Conexion
{
  public function listarInscripcion($pagina = 1)
  {
    $inicio = 0;
    $cantidad = 50;
    if ($pagina > 1) {
      $inicio = ($cantidad * ($pagina - 1)) + 1;
      $cantidad = $inicio + $cantidad;
    }
    $query = "SELECT * FROM inscripcion AS i INNER JOIN usuario AS u ON u.id=i.id_usuario LIMIT $inicio, $cantidad";
    $datos = parent::obtenerDatos($query);
    return $datos;
  }
  public function listarId($id)
  {
    $query = "SELECT * FROM inscripcion AS i INNER JOIN usuario AS u ON u.id=i.id_usuario WHERE id_inscripcion = $id";
    $datos = parent::obtenerDatos($query);
    return $datos;
  }
  public function Inscripcion($json)
  {
    $_respuestas = new respuestas;
    $datos = json_decode($json, true);
    $usuario = $_SESSION["id"];
    $programa = isset($datos["programa"]) ? $datos["programa"] : "";
    $fecha = isset($datos["fecha"]) ? $datos["fecha"] : "";
    if (!isset($datos['programa']) || !isset($datos['fecha'])) {
      // devolver respuesta de error campos de entradas mal escritos o vacios
      return $_respuestas->error_400();
    } else {
      $valreg = $this->obtenerInscripcion($programa, $usuario);
      if (!$valreg) {
        $datos = $this->registrarInscripcion($usuario, $programa, $fecha);
        return $_respuestas->registrado();
      } else {
        //  devolver error si el usuario no existe
        $nombre = $valreg[0]['nombre'];
        $apellido = $valreg[0]['apellido'];
        $nomcom = $nombre . ' ' . $apellido;
        return $_respuestas->error_200("La inscripcion al programa '$programa' del usuario '$nomcom' ya esta registrada");
      }
    }
  }
  private function registrarInscripcion($usuario, $programa, $fecha)
  {

    $query = "INSERT INTO inscripcion(programa, fecha, id_usuario) VALUES ('$programa','$fecha','$usuario')";
    // obtener datos de la base de datos y devolverlos por la funcion
    $datos = parent::registrar($query);
    if (isset($datos)) {
      return $datos;
    } else {
      return 0;
    }
  }
  private function obtenerInscripcion($programa, $usuario)
  {
    $query = "SELECT * FROM inscripcion AS i INNER JOIN usuario AS u ON u.id=i.id_usuario  WHERE i.programa = '$programa' AND i.id_usuario = '$usuario'";
    // obtener datos de la base de datos y devolverlos por la funcion
    $datos = parent::obtenerDatos($query);
    if (isset($datos)) {
      return $datos;
    } else {
      return 0;
    }
  }
}
