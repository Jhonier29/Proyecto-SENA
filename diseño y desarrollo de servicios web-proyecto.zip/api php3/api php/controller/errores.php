<?php
// Clases de respuestas a errores o excepciones
class respuestas
{
  // vAriable de Respuesta correcta mas datos del usuario logeado
  public $response = [
    "status" => "Correcto",
    "result" => array()
  ];

  // Respuesta de error metodo o uso no permitido
  public function error_405()
  {
    $this->response["status"] = "error";
    $this->response["result"] = array(
      "error_id" => "405",
      "error_msg"  => "Metodo o uso no permitido por favor use POST"
    );
    return $this->response;
  }
  // Respuesta de error datos incorrectos 
  public function error_200($opcional = "Datos incorrectos")
  {
    $this->response["status"] = "error";
    $this->response["result"] = array(
      "error_id" => "200",
      "error_msg"  => $opcional
    );
    return $this->response;
  }
  // Respuesta de error datos incompletos o correctos
  public function error_400()
  {
    $this->response["status"] = "error";
    $this->response["result"] = array(
      "error_id" => "400",
      "error_msg"  => "Datos incompletos o con formatos incorrectos"
    );
    return $this->response;
  }
  // Respuesta de error servidor
  public function error_500($opcional = "Error interno Servidor")
  {
    $this->response["status"] = "error";
    $this->response["result"] = array(
      "error_id" => "500",
      "error_msg"  => $opcional
    );
    return $this->response;
  }
  public function registrado()
  {
    $this->response = [
      "Registro guardado Correctamente",
    ];
    return $this->response;
  }
}
