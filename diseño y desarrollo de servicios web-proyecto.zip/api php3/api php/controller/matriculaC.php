<?php

require_once "conexion.php";
require_once "errores.php";

class matricula extends Conexion
{

  public function listarMatricula($pagina = 1)
  {
    $inicio = 0;
    $cantidad = 50;
    if ($pagina > 1) {
      $inicio = ($cantidad * ($pagina - 1)) + 1;
      $cantidad = $inicio + $cantidad;
    }
    $query = "SELECT * FROM inscripcion AS i INNER JOIN usuario AS s ON s.id=i.id_usuario INNER JOIN matricula AS u ON u.id_inscripcion=i.id_inscripcion LIMIT $inicio, $cantidad";
    $datos = parent::obtenerDatos($query);
    return $datos;
  }
  public function listarId($id)
  {
    $query = "SELECT * FROM inscripcion AS i INNER JOIN usuario AS s ON s.id=i.id_usuario INNER JOIN matricula AS u ON u.id_inscripcion=i.id_inscripcion WHERE u.id_matricula = $id";
    $datos = parent::obtenerDatos($query);
    return $datos;
  }
  public function matricula($json)
  {
    $_respuestas = new respuestas;
    $datos = json_decode($json, true);
    $usuario = $_SESSION["id"];
    $programa = isset($datos["programa"]) ? $datos["programa"] : "";
    $fecha = isset($datos["fecha"]) ? $datos["fecha"] : "";
    if (!isset($datos['programa']) || !isset($datos['fecha'])) {
      // devolver respuesta de error campos de entradas mal escritos o vacios
      return $_respuestas->error_400();
    } else {
      $valreg = $this->obtenermatricula($programa, $usuario);
      if (!$valreg) {
        $datos = $this->registrarmatricula($usuario, $programa, $fecha);
        return $_respuestas->registrado();
      } else {
        //  devolver error si el usuario no existe
        $nombre = $valreg[0]['nombre'];
        $apellido = $valreg[0]['apellido'];
        $nomcom = $nombre . ' ' . $apellido;
        return $_respuestas->error_200("La matricula al programa '$programa' del usuario '$nomcom' ya esta registrada");
      }
    }
  }
  private function registrarmatricula($id_matricula, $estado, $programa, $fecha_inicio, $id_inscripcion)
  {

    $query = "INSERT INTO matricula(id_matricula, estado, programa, fecha_inicio, id_inscripcion) VALUES ('$id_matricula','$estado','$programa','$fecha_inicio, '$id_inscripcion'')";
    // obtener datos de la base de datos y devolverlos por la funcion
    $datos = parent::registrar($query);
    if (isset($datos)) {
      return $datos;
    } else {
      return 0;
    }
  }
  private function obtenermatricula($programa, $usuario, $estado)
  {
    $query = "SELECT * FROM matricula AS i INNER JOIN usuario AS u ON u.id=i.id_usuario= WHERE i.programa = '$programa' AND i.id_usuario = '$usuario'";
    // obtener datos de la base de datos y devolverlos por la funcion
    $datos = parent::obtenerDatos($query);
    if (isset($datos)) {
      return $datos;
    } else {
      return 0;
    }
  }
}
