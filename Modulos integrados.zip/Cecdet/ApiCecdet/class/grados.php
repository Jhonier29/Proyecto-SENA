<?php
    class grados {
        private $conn;
        private $db_table = "grados";

        public $id;
        public $descripcion;
        public $idProfesor;

        public function __construct($db) {
            $this->conn = $db;
        }

        public function crearGrados(){
            $sqlQuery = "INSERT INTO
                        ". $this->db_table ."
                    (descripcion, idProfesor) values (
                        :descripcion, 
                        :idProfesor)" ;
        
            $stmt = $this->conn->prepare($sqlQuery);
        
            // sanitize
           
            $this->descripcion=htmlspecialchars(strip_tags($this->descripcion));
            $this->idProfesor=htmlspecialchars(strip_tags($this->idProfesor));
        
            // bind data
            
            $stmt->bindParam(":descripcion", $this->descripcion);
            $stmt->bindParam(":idProfesor", $this->idProfesor);
        
            if($stmt->execute()){
               return true;
            }
            return false;
        }

        public function actualizargrados(){
            $sqlQuery = "Update
                        ". $this->db_table ."
                    Set 
                        id=:id, 
                        descripcion=:descripcion, 
                        idProfesor=idProfesor";
        
            $stmt = $this->conn->prepare($sqlQuery);
        
            // sanitize
            $this->id=htmlspecialchars(strip_tags($this->id));
            $this->descripcion=htmlspecialchars(strip_tags($this->descripcion));
            $this->idProfesor=htmlspecialchars(strip_tags($this->idProfesor));
          
            // bind data
            $stmt->bindParam(":id", $this->id);
            $stmt->bindParam(":descripcion", $this->descripcion);
            $stmt->bindParam(":idProfesor", $this->idProfesor);
            
            if($stmt->execute()){
               return true;
            }
            return false;
        }

        public function consultargrados(){
            $sqlQuery = "SELECT * FROM " . $this->db_table . "";
            $stmt = $this->conn->prepare($sqlQuery);
            $stmt->execute();
            return $stmt;
        }

        public function consultargradosPorId(){
            $sqlQuery = "SELECT * FROM " . $this->db_table . "
                    WHERE 
                        id = ?
                    LIMIT 0,1";

            $stmt = $this->conn->prepare($sqlQuery);

            $stmt->bindParam(1, $this->id);

            $stmt->execute();

            $dataRow = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $this->id = $dataRow['id'];
            $this->descripcion = $dataRow['descripcion'];
            $this->idProfesor = $dataRow['idProfesor'];
           
        }  

        function eliminargrados(){
            $sqlQuery = "DELETE FROM " . $this->db_table . " WHERE id = :id";
            $stmt = $this->conn->prepare($sqlQuery);
                    
            $this->id=htmlspecialchars(strip_tags($this->id));
            
            $stmt->bindParam(":id", $this->id);
                    
            if($stmt->execute()){
                return true;
            }
            return false;
        }
    }
?>