<?php
    class alumnos {
        private $conn;
        private $db_table = "alumnos";

        public $id;
        public $nombre;
        public $apellido;
        public $direccion;
        public $telefono;
        public $idAcudiente;
        public $fecha_nacimiento;
        public $estado;
        public $idGrados;


        public function __construct($db) {
            $this->conn = $db;
        }

        public function crearAlumnos(){
            $sqlQuery = "INSERT INTO
                        ". $this->db_table ."
                    (nombre, apellido, direccion, telefono,  idAcudiente, fecha_nacimiento, estado, idGrados) 
                    values (
                        :nombre, 
                        :apellido, 
                        :direccion, 
                        :telefono, 
                        :idAcudiente,
                        :fecha_nacimiento, 
                        :estado,
                        :idGrados)" ;

        
            $stmt = $this->conn->prepare($sqlQuery);
        
            // sanitize
            $this->nombre=htmlspecialchars(strip_tags($this->nombre));
            $this->apellido=htmlspecialchars(strip_tags($this->apellido));
            $this->direccion=htmlspecialchars(strip_tags($this->direccion));
            $this->telefono=htmlspecialchars(strip_tags($this->telefono));
            $this->idAcudiente=htmlspecialchars(strip_tags($this->idAcudiente));
            $this->fecha_nacimiento=htmlspecialchars(strip_tags($this->fecha_nacimiento));
            $this->estado=htmlspecialchars(strip_tags($this->estado));
            $this->idGrados=htmlspecialchars(strip_tags($this->idGrados));
        
            // bind data
            $stmt->bindParam(":nombre", $this->nombre);
            $stmt->bindParam(":apellido", $this->apellido);
            $stmt->bindParam(":direccion", $this->direccion);
            $stmt->bindParam(":telefono", $this->telefono);
            $stmt->bindParam(":idAcudiente", $this->idAcudiente);
            $stmt->bindParam(":fecha_nacimiento", $this->fecha_nacimiento);
            $stmt->bindParam(":estado", $this->estado);
            $stmt->bindParam(":idGrados", $this->idGrados);
        
            if($stmt->execute()){
               return true;
            }
            return false;
    }
    public function actualizar(){
        $sqlQuery = "Update
                    ". $this->db_table ."
                Set 
                    nombre=:nombre, 
                    apellido=:apellido, 
                    direccion=:direccion, 
                    telefono=:telefono, 
                    fecha_nacimiento=:Fecha_nacimiento,
                    idAcudiente=: idAcudiente,
                    fecha_nacimiento=:Fecha_nacimiento,
                    estado=: estado
                    idGrados=:idGrados ";
    
        $stmt = $this->conn->prepare($sqlQuery);
    
        // sanitize
        $this->nombre=htmlspecialchars(strip_tags($this->nombre));
        $this->apellido=htmlspecialchars(strip_tags($this->apellido));
        $this->direccion=htmlspecialchars(strip_tags($this->direccion));
        $this->telefono=htmlspecialchars(strip_tags($this->telefono));
        $this->idAcudiente=htmlspecialchars(strip_tags($this->idAcudiente));
        $this->fecha_nacimiento=htmlspecialchars(strip_tags($this->fecha_nacimiento));
        $this->estado=htmlspecialchars(strip_tags($this->estado));
        $this->idGrados=htmlspecialchars(strip_tags($this->idGrados));
    
        // bind data
        $stmt->bindParam(":nombre", $this->nombre);
        $stmt->bindParam(":apellido", $this->apellido);
        $stmt->bindParam(":direccion", $this->direccion);
        $stmt->bindParam(":telefono", $this->telefono);
        $stmt->bindParam(":idAcudiente", $this->idAcudiente);
        $stmt->bindParam(":fecha_nacimirnto", $this->fecha_nacimiento);
        $stmt->bindParam(":estado", $this->estado);
        $stmt->bindParam(":idGrados", $this->idGrados);
        
        if($stmt->execute()){
           return true;
        }
        return false;
    }
    public function consultarAlumno(){
        $sqlQuery = "SELECT * FROM " . $this->db_table . "";
        $stmt = $this->conn->prepare($sqlQuery);
        $stmt->execute();
        return $stmt;
    }

    public function consultarAlumnosPorId(){
        $sqlQuery = "SELECT * FROM " . $this->db_table . "
                WHERE 
                    id = ?
                LIMIT 0,1";

        $stmt = $this->conn->prepare($sqlQuery);

        $stmt->bindParam(1, $this->id);

        $stmt->execute();

        $dataRow = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $this->nombre = $dataRow['nombre'];
        $this->apellido = $dataRow['apellido'];
        $this->direccion = $dataRow['direccion'];
        $this->telefono = $dataRow['telefono'];
        $this->idAcudiente = $dataRow['idAcudiente'];
        $this->fecha_nacimiento = $dataRow['fecha_nacimiento'];
        $this->estado = $dataRow['estado'];
        $this->idGrados = $dataRow['idGrados'];
    }  

    function eliminarAlumnos(){
        $sqlQuery = "DELETE FROM " . $this->db_table . " WHERE id = :id";
        $stmt = $this->conn->prepare($sqlQuery);
                
        $this->id=htmlspecialchars(strip_tags($this->id));
        
        $stmt->bindParam(":id", $this->id);
                
        if($stmt->execute()){
            return true;
        }
        return false;
    }
}
?>