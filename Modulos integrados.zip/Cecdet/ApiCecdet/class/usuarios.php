<?php
    class usuarios {
        private $conn;
        private $db_table = "usuario";

        public $id;
        public $nombre;
        public $usuario;
        public $clave;
        public $admin; 
        public $activo;

        public function __construct($db) {
            $this->conn = $db;
        }

        public function crearUsuario(){
            $sqlQuery = "INSERT INTO
                        ". $this->db_table ."
                    (nombre, usuario, clave, admin, activo) values (
                        :nombre, 
                        :usuario, 
                        md5(:clave), 
                        0, 
                        1)";
        
            $stmt = $this->conn->prepare($sqlQuery);
        
            // sanitize
            $this->nombre=htmlspecialchars(strip_tags($this->nombre));
            $this->usuario=htmlspecialchars(strip_tags($this->usuario));
            $this->clave=htmlspecialchars(strip_tags($this->clave));
        
            // bind data
            $stmt->bindParam(":nombre", $this->nombre);
            $stmt->bindParam(":usuario", $this->usuario);
            $stmt->bindParam(":clave", $this->clave);
        
            if($stmt->execute()){
               return true;
            }
            return false;
        }

        public function actualizarUsuario(){
            $sqlQuery = "Update
                        ". $this->db_table ."
                    Set 
                        nombre=:nombre, 
                        usuario=:usuario, 
                        clave=md5(:clave), 
                        admin=:admin, 
                        activo=:activo
                    where id = :id";
        
            $stmt = $this->conn->prepare($sqlQuery);
        
            // sanitize
            $this->nombre=htmlspecialchars(strip_tags($this->nombre));
            $this->usuario=htmlspecialchars(strip_tags($this->usuario));
            $this->clave=htmlspecialchars(strip_tags($this->clave));
            $this->admin=htmlspecialchars(strip_tags($this->admin));
            $this->activo=htmlspecialchars(strip_tags($this->activo));
            $this->id=htmlspecialchars(strip_tags($this->id));
        
            // bind data
            $stmt->bindParam(":nombre", $this->nombre);
            $stmt->bindParam(":usuario", $this->usuario);
            $stmt->bindParam(":clave", $this->clave);
            $stmt->bindParam(":admin", $this->admin);
            $stmt->bindParam(":activo", $this->activo);
            $stmt->bindParam(":id", $this->id);
        
            if($stmt->execute()){
               return true;
            }
            return false;
        }

        public function consultarUsuario(){
            $sqlQuery = "SELECT * FROM " . $this->db_table . "";
            $stmt = $this->conn->prepare($sqlQuery);
            $stmt->execute();
            return $stmt;
        }

        public function consultarUsuarioPorId(){
            $sqlQuery = "SELECT * FROM " . $this->db_table . "
                    WHERE 
                        id = ?
                    LIMIT 0,1";

            $stmt = $this->conn->prepare($sqlQuery);

            $stmt->bindParam(1, $this->id);

            $stmt->execute();

            $dataRow = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $this->nombre = $dataRow['nombre'];
            $this->usuario = $dataRow['usuario'];
            $this->clave = $dataRow['clave'];
            $this->admin = $dataRow['admin'];
            $this->activo = $dataRow['activo'];
        }  

        function eliminarUsuario(){
            $sqlQuery = "DELETE FROM " . $this->db_table . " WHERE id = :id";
            $stmt = $this->conn->prepare($sqlQuery);
                    
            $this->id=htmlspecialchars(strip_tags($this->id));
            
            $stmt->bindParam(":id", $this->id);
                    
            if($stmt->execute()){
                return true;
            }
            return false;
        }
    }
?>