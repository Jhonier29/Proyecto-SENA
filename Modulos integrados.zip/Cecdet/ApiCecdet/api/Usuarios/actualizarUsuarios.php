<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../class/usuarios.php';

    $database = new Database();
    $db = $database->getConnection();

    $item = new Usuarios($db);

    $data = json_decode(file_get_contents("php://input"));

    $item->id = $data->id;
    $item->nombre = $data->nombre;
    $item->usuario = $data->usuario;
    $item->clave = $data->clave;
    $item->admin = $data->admin;
    $item->activo = $data->activo;
    
    if($item->actualizarUsuario()){
        echo json_encode("Registro actualizado exitosamente.");
    } else{
        echo json_encode("Datos No guardados");
    }
?>