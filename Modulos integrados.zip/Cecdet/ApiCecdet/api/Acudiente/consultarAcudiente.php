<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    
    include_once '../../config/database.php';
    include_once '../../class/acudientes.php';

    $database = new Database();
    $db = $database->getConnection();

    $items = new Acudiente($db);

    $stmt = $items->consultarAcudiente ();
    $itemCount = $stmt->rowCount();

    echo json_encode($itemCount);

    if($itemCount > 0){
        
        $registroArr = array();
        $registroArr["body"] = array();
        $registroArr["itemCount"] = $itemCount;

        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $e = array(
                "id" => $id,
                "nombre" => $nombre,
                "apellido" => $apellido,
                "direccion" => $direccion,
                "telefono" => $telefono,
                "correo" => $correo,
              
            );
            
            array_push($registroArr["body"], $e);
        }
        echo json_encode($registroArr);
    }

    else{
        http_response_code(404);
        echo json_encode("No hay registros.");
    }
?>