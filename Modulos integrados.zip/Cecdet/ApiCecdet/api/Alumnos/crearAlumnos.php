<?php
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    header("Access-Control-Allow-Methods: POST");
    header("Access-Control-Max-Age: 3600");
    header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

    include_once '../../config/database.php';
    include_once '../../class/alumnos.php';

    $database = new Database();
    $db = $database->getConnection();

    $item = new alumnos ($db);

    $data = json_decode(file_get_contents("php://input"));

    $item->nombre = $data->nombre;
    $item->apellido = $data->apellido;
    $item->direccion = $data->direccion;
    $item->telefono = $data->telefono;
    $item->fecha_nacimiento = $data->fecha_nacimiento;
    $item->idAcudiente = $data->idAcudiente;
    $item->estado = $data->estado;
    $item->idGrados = $data->idGrados;

    
    
    
    if($item->crearAlumnos()){
        echo json_encode("Registro creado exitosamente.");
    } else{
        echo json_encode("Datos No guardados");
    }
?>