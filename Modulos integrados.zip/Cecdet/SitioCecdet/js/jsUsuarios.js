// Función para realizar la solicitud a la API
async function apiRequest(url, method, data) {
    const options = {
        method: method,
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    };
    if (method === 'GET' || method === 'DELETE') {
        delete options.body;
    }
    try {
        const response = await fetch(url, options);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const responseData = await response.json();
        return responseData;
    } catch (error) {
        console.error('API request failed:', error);
        showModal('Ha ocurrido un error al procesar la solicitud.', false);
    }
}

// Función para mostrar un mensaje modal
function showModal(message, isSuccess) {
    const modal = document.createElement('div');
    modal.style.position = 'fixed';
    modal.style.top = '10px';
    modal.style.left = '50%';
    modal.style.transform = 'translateX(-50%)';
    modal.style.padding = '10px 20px';
    modal.style.borderRadius = '5px';
    modal.style.backgroundColor = isSuccess ? '#ccffcc' : '#ffcccc';
    modal.style.color = 'black';
    modal.style.zIndex = '1000';
    modal.innerText = message;

    document.body.appendChild(modal);

    // Eliminar el modal después de 3 segundos
    setTimeout(() => {
        document.body.removeChild(modal);
    }, 3000);
}

// Función para limpiar los inputs del formulario
function clearForm() {
    document.getElementById('nombre').value = '';
    document.getElementById('usuario').value = '';
    document.getElementById('clave').value = '';
    
    // Colocar el foco en el input de nombre
    focoEnNombre();
}

function focoEnNombre(){
    // Colocar el foco en el input de nombre
    document.getElementById('nombre').focus();
}

// Función para validar los campos del formulario
function validateForm(fields) {
    for (const field of fields) {
        if (!field.value.trim()) {
            showModal(`Por favor, complete el campo ${field.placeholder}.`, false);
            return false;
        }
    }
    return true;
}

// Actualiza las funciones CRUD para incluir validaciones y mostrar mensajes modales
async function registrarse() {
    const nombre = document.getElementById('nombre');
    const usuario = document.getElementById('usuario');
    const clave = document.getElementById('clave');

    if (validateForm([nombre, usuario, clave])) {
        const usuarioData = {
            nombre: document.getElementById('nombre').value,
            usuario: document.getElementById('usuario').value,
            clave: document.getElementById('clave').value,
        };
        const url = 'http://127.0.0.1/Cecdet/ApiCecdet/api/usuarios/crearUsuarios.php';
        const response = await apiRequest(url, 'POST', usuarioData);
        showModal(response, true);
        
        // Función para limpiar los inputs del formulario
        clearForm();
        // Colocar el foco en el input de nombre
        focoEnNombre();
    }
}
